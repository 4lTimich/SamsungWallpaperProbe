package com.example.samsungwallpaperprobe;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Locale;

/**
 * v0.22: track ONE anchor icon. The accessibility tree is traversed only to acquire
 * that icon; once acquired, subsequent polls call refresh() on the cached node.
 */
public class LauncherAccessibilityService extends AccessibilityService {
    private static final String LAUNCHER = "com.sec.android.app.launcher";
    private static final long POLL_MS = 8L;
    private static final long CALIBRATION_STABLE_MS = 320L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running = false;
    private AccessibilityNodeInfo cachedAnchor = null;
    private String cachedLabel = "";
    private int lastLeft = Integer.MIN_VALUE;
    private int lastTop = Integer.MIN_VALUE;
    private int lastRight = Integer.MIN_VALUE;
    private int lastBottom = Integer.MIN_VALUE;
    private long lastRectChangeMs = 0L;

    private final Runnable boundsPoll = new Runnable() {
        @Override public void run() {
            if (!running) return;
            sampleAnchorBounds();
            handler.postDelayed(this, POLL_MS);
        }
    };

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        LauncherScrollBus.serviceConnected = true;
        running = true;
        handler.removeCallbacks(boundsPoll);
        handler.post(boundsPoll);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null || !LAUNCHER.contentEquals(pkg)) return;

        long now = SystemClock.uptimeMillis();
        LauncherScrollBus.eventUptimeMs = now;
        LauncherScrollBus.eventType = event.getEventType();
        LauncherScrollBus.scrollX = event.getScrollX();
        LauncherScrollBus.scrollY = event.getScrollY();
        LauncherScrollBus.maxScrollX = event.getMaxScrollX();
        LauncherScrollBus.maxScrollY = event.getMaxScrollY();
        if (Build.VERSION.SDK_INT >= 28) {
            LauncherScrollBus.deltaX = event.getScrollDeltaX();
            LauncherScrollBus.deltaY = event.getScrollDeltaY();
        } else {
            LauncherScrollBus.deltaX = 0;
            LauncherScrollBus.deltaY = 0;
        }
        LauncherScrollBus.fromIndex = event.getFromIndex();
        LauncherScrollBus.toIndex = event.getToIndex();
        LauncherScrollBus.itemCount = event.getItemCount();
        LauncherScrollBus.className = event.getClassName() == null ? "" : event.getClassName().toString();
        LauncherScrollBus.sequence++;

        SwipeTrace.log(now, "A11Y", "EVENT",
                Float.NaN, Float.NaN, Float.NaN, Float.NaN,
                LauncherScrollBus.boundsFound ? LauncherScrollBus.boundsCenterX : Integer.MIN_VALUE,
                LauncherScrollBus.boundsPosition, Float.NaN,
                -1, -1,
                String.format(Locale.US, "type=%d scroll=%d/%d dx=%d idx=%d>%d count=%d",
                        event.getEventType(), event.getScrollX(), event.getMaxScrollX(),
                        LauncherScrollBus.deltaX, event.getFromIndex(), event.getToIndex(), event.getItemCount()));

        sampleAnchorBounds();
    }

    private void sampleAnchorBounds() {
        final long now = SystemClock.uptimeMillis();
        final android.content.SharedPreferences prefs = getSharedPreferences(Prefs.PREFS, MODE_PRIVATE);
        String anchor = prefs.getString(Prefs.KEY_BOUNDS_ANCHOR_LABEL, Prefs.DEFAULT_BOUNDS_ANCHOR_LABEL);
        if (anchor == null) anchor = "";
        anchor = anchor.trim();
        if (anchor.isEmpty()) { publishMissing(anchor, now); return; }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { publishMissing(anchor, now); return; }
        CharSequence rootPkg = root.getPackageName();
        if (rootPkg == null || !LAUNCHER.contentEquals(rootPkg)) {
            cachedAnchor = null;
            publishMissing(anchor, now);
            return;
        }

        if (!anchor.equals(cachedLabel)) {
            cachedAnchor = null;
            cachedLabel = anchor;
        }

        AccessibilityNodeInfo node = cachedAnchor;
        boolean usable = false;
        if (node != null) {
            try { usable = node.refresh(); } catch (Throwable ignored) { usable = false; }
        }
        if (!usable) {
            cachedAnchor = findAnchor(root, anchor);
            node = cachedAnchor;
        }
        if (node == null) { publishMissing(anchor, now); return; }

        Rect r = new Rect();
        try { node.getBoundsInScreen(r); } catch (Throwable ignored) { publishMissing(anchor, now); return; }
        if (r.width() <= 0 || r.height() <= 0) { publishMissing(anchor, now); return; }

        boolean changed = r.left != lastLeft || r.top != lastTop || r.right != lastRight || r.bottom != lastBottom;
        if (changed) {
            lastLeft = r.left; lastTop = r.top; lastRight = r.right; lastBottom = r.bottom;
            lastRectChangeMs = now;
            LauncherScrollBus.boundsChanges++;
            LauncherScrollBus.boundsChangeSequence++;
            LauncherScrollBus.boundsChangeUptimeMs = now;
        }

        // Calibration is deliberately performed only after the real icon is stationary.
        if (prefs.getBoolean(Prefs.KEY_BOUNDS_ANCHOR_CALIBRATE_PENDING, false)
                && now - lastRectChangeMs >= CALIBRATION_STABLE_MS) {
            int page = prefs.getInt(Prefs.KEY_BOUNDS_ANCHOR_PAGE,
                    prefs.getInt(Prefs.KEY_SAVED_PAGE, 0));
            prefs.edit()
                    .putInt(Prefs.KEY_BOUNDS_ANCHOR_REST_X, r.centerX())
                    .putInt(Prefs.KEY_BOUNDS_ANCHOR_REST_Y, r.centerY())
                    .putBoolean(Prefs.KEY_BOUNDS_ANCHOR_CALIBRATE_PENDING, false)
                    .apply();
            LauncherScrollBus.boundsAnchorPage = page;
            LauncherScrollBus.boundsRestX = r.centerX();
            LauncherScrollBus.boundsRestY = r.centerY();
        }

        int anchorPage = prefs.getInt(Prefs.KEY_BOUNDS_ANCHOR_PAGE, -1);
        int restX = prefs.getInt(Prefs.KEY_BOUNDS_ANCHOR_REST_X, -1);
        int restY = prefs.getInt(Prefs.KEY_BOUNDS_ANCHOR_REST_Y, -1);
        int displayW = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        boolean calibrated = anchorPage >= 0 && restX >= 0;
        float pos = calibrated ? anchorPage + (restX - r.centerX()) / (float) displayW : Float.NaN;

        LauncherScrollBus.boundsAnchor = anchor;
        LauncherScrollBus.boundsFound = true;
        LauncherScrollBus.boundsCalibrated = calibrated;
        LauncherScrollBus.boundsAnchorPage = anchorPage;
        LauncherScrollBus.boundsRestX = restX;
        LauncherScrollBus.boundsRestY = restY;
        LauncherScrollBus.boundsLeft = r.left;
        LauncherScrollBus.boundsTop = r.top;
        LauncherScrollBus.boundsRight = r.right;
        LauncherScrollBus.boundsBottom = r.bottom;
        LauncherScrollBus.boundsCenterX = r.centerX();
        LauncherScrollBus.boundsCenterY = r.centerY();
        LauncherScrollBus.boundsPosition = pos;
        LauncherScrollBus.boundsNodeText = nodeLabel(node);
        LauncherScrollBus.boundsUptimeMs = now;
        LauncherScrollBus.boundsSamples++;
        LauncherScrollBus.boundsSequence++;

        if (changed) {
            SwipeTrace.log(now, "BOUNDS", "CHANGE",
                    Float.NaN, Float.NaN, Float.NaN, Float.NaN,
                    r.centerX(), pos, Float.NaN,
                    anchorPage, -1,
                    "restX=" + restX + " y=" + r.centerY());
        }
    }

    private void publishMissing(String anchor, long now) {
        LauncherScrollBus.boundsAnchor = anchor;
        LauncherScrollBus.boundsFound = false;
        LauncherScrollBus.boundsUptimeMs = now;
        LauncherScrollBus.boundsSamples++;
        LauncherScrollBus.boundsSequence++;
    }

    private AccessibilityNodeInfo findAnchor(AccessibilityNodeInfo root, String anchor) {
        try {
            List<AccessibilityNodeInfo> matches = root.findAccessibilityNodeInfosByText(anchor);
            AccessibilityNodeInfo best = chooseBest(matches, anchor);
            if (best != null) return best;
        } catch (Throwable ignored) {}

        String needle = normalize(anchor);
        ArrayDeque<AccessibilityNodeInfo> q = new ArrayDeque<>();
        q.add(root);
        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MIN_VALUE;
        int seen = 0;
        while (!q.isEmpty() && seen < 900) {
            AccessibilityNodeInfo n = q.removeFirst();
            seen++;
            int score = matchScore(nodeLabel(n), needle, n);
            if (score > bestScore) { bestScore = score; best = n; }
            int cc = n.getChildCount();
            for (int i = 0; i < cc && seen + q.size() < 900; i++) {
                AccessibilityNodeInfo child = n.getChild(i);
                if (child != null) q.addLast(child);
            }
        }
        return bestScore >= 100 ? best : null;
    }

    private AccessibilityNodeInfo chooseBest(List<AccessibilityNodeInfo> nodes, String anchor) {
        if (nodes == null || nodes.isEmpty()) return null;
        String needle = normalize(anchor);
        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MIN_VALUE;
        for (AccessibilityNodeInfo n : nodes) {
            if (n == null) continue;
            int score = matchScore(nodeLabel(n), needle, n);
            if (score > bestScore) { bestScore = score; best = n; }
        }
        return bestScore >= 100 ? best : null;
    }

    private int matchScore(String label, String needle, AccessibilityNodeInfo node) {
        if (needle.isEmpty()) return Integer.MIN_VALUE;
        String hay = normalize(label);
        if (hay.isEmpty()) return Integer.MIN_VALUE;
        int score;
        if (hay.equals(needle)) score = 500;
        else if (hay.startsWith(needle + " ") || hay.startsWith(needle + ",")) score = 430;
        else if (hay.contains(needle)) score = 300;
        else return Integer.MIN_VALUE;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        int min = Math.min(r.width(), r.height());
        int max = Math.max(r.width(), r.height());
        if (min >= 50 && max <= 450) score += 80;
        if (node.isClickable()) score += 30;
        if (node.isVisibleToUser()) score += 20;
        return score;
    }

    private String nodeLabel(AccessibilityNodeInfo node) {
        StringBuilder s = new StringBuilder();
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null && t.length() > 0) s.append(t);
        if (d != null && d.length() > 0) {
            if (s.length() > 0) s.append(" | ");
            s.append(d);
        }
        return s.toString();
    }

    private String normalize(String s) {
        if (s == null) return "";
        return s.toLowerCase(Locale.ROOT).replace('\u00a0', ' ').trim();
    }

    @Override public void onInterrupt() {}

    @Override public boolean onUnbind(android.content.Intent intent) {
        running = false;
        handler.removeCallbacks(boundsPoll);
        cachedAnchor = null;
        LauncherScrollBus.serviceConnected = false;
        LauncherScrollBus.boundsFound = false;
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        running = false;
        handler.removeCallbacks(boundsPoll);
        cachedAnchor = null;
        LauncherScrollBus.serviceConnected = false;
        LauncherScrollBus.boundsFound = false;
        super.onDestroy();
    }
}
