package com.example.samsungwallpaperprobe;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SAVE_TRACE = 2201;

    private SharedPreferences prefs;
    private TextView pagesValue;
    private TextView currentValue;
    private EditText anchorEdit;
    private TextView anchorStatus;
    private TextView recorderStatus;
    private Button debugButton;
    private Button recordButton;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(Prefs.PREFS, MODE_PRIVATE);
        Prefs.ensureV06GridDefaults(prefs,
                getResources().getDisplayMetrics().widthPixels,
                getResources().getDisplayMetrics().heightPixels);
        ensureDefaults();
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private void ensureDefaults() {
        SharedPreferences.Editor e = prefs.edit();
        if (!prefs.contains(Prefs.KEY_PAGE_COUNT)) e.putInt(Prefs.KEY_PAGE_COUNT, 4);
        if (!prefs.contains(Prefs.KEY_SAVED_PAGE)) e.putInt(Prefs.KEY_SAVED_PAGE, 0);
        if (!prefs.contains(Prefs.KEY_SWIPE_SENSITIVITY)) e.putFloat(Prefs.KEY_SWIPE_SENSITIVITY, 1.80f);
        if (!prefs.contains(Prefs.KEY_SHOW_DEBUG)) e.putBoolean(Prefs.KEY_SHOW_DEBUG, false);
        if (!prefs.contains(Prefs.KEY_GLASS_START_PHASE_PX)) e.putFloat(Prefs.KEY_GLASS_START_PHASE_PX, Prefs.DEFAULT_GLASS_START_PHASE_PX);
        if (!prefs.contains(Prefs.KEY_BOUNDS_ANCHOR_LABEL)) e.putString(Prefs.KEY_BOUNDS_ANCHOR_LABEL, Prefs.DEFAULT_BOUNDS_ANCHOR_LABEL);
        e.apply();
    }

    private void buildUi() {
        int pad = dp(22);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(pad, pad, pad, dp(40));
        root.setBackgroundColor(Color.rgb(248, 248, 248));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Hybrid Anchor + Swipe Recorder v0.22", 24f, Color.BLACK, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView intro = text(
                "Возвращаемся к сетке и пальцу. Одна выбранная иконка One UI теперь служит абсолютной точкой привязки: boundsInScreen исправляет накопившуюся ошибку, а палец заполняет промежутки между редкими обновлениями Samsung. Параллельно можно записать трассу свайпов и прислать её мне.",
                15f, Color.DKGRAY, false);
        intro.setGravity(Gravity.CENTER);
        intro.setPadding(0, dp(10), 0, dp(18));
        root.addView(intro, matchWrap());

        root.addView(text("Количество страниц", 17f, Color.BLACK, true), matchWrap());
        pagesValue = text("", 28f, Color.BLACK, true);
        pagesValue.setGravity(Gravity.CENTER);
        root.addView(makeStepper(pagesValue, true), matchWrap());

        TextView c = text("Текущая страница", 17f, Color.BLACK, true);
        c.setPadding(0, dp(12), 0, 0);
        root.addView(c, matchWrap());
        currentValue = text("", 28f, Color.BLACK, true);
        currentValue.setGravity(Gravity.CENTER);
        root.addView(makeStepper(currentValue, false), matchWrap());

        Button grid = new Button(this);
        grid.setText("РЕДАКТОР СЕТКИ И СТЕКЛА");
        grid.setOnClickListener(v -> startActivity(new Intent(this, GridEditorActivity.class)));
        LinearLayout.LayoutParams gp = matchWrap(); gp.setMargins(0, dp(16), 0, dp(8));
        root.addView(grid, gp);

        TextView anchorTitle = text("Иконка-якорь", 18f, Color.BLACK, true);
        anchorTitle.setGravity(Gravity.CENTER);
        root.addView(anchorTitle, matchWrap());

        anchorEdit = new EditText(this);
        anchorEdit.setSingleLine(true);
        anchorEdit.setText(prefs.getString(Prefs.KEY_BOUNDS_ANCHOR_LABEL, Prefs.DEFAULT_BOUNDS_ANCHOR_LABEL));
        anchorEdit.setHint("Например Pinterest");
        anchorEdit.setTextSize(17f);
        root.addView(anchorEdit, matchWrap());

        Button calibrate = new Button(this);
        calibrate.setText("КАЛИБРОВАТЬ ЯКОРЬ НА ТЕКУЩЕЙ СТРАНИЦЕ");
        calibrate.setOnClickListener(v -> calibrateAnchor());
        root.addView(calibrate, matchWrap());

        anchorStatus = text("", 14f, Color.DKGRAY, true);
        anchorStatus.setGravity(Gravity.CENTER);
        anchorStatus.setPadding(0, dp(5), 0, dp(8));
        root.addView(anchorStatus, matchWrap());

        Button access = new Button(this);
        access.setText("ОТКРЫТЬ СПЕЦИАЛЬНЫЕ ВОЗМОЖНОСТИ");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access, matchWrap());

        TextView recTitle = text("Запись свайпов", 18f, Color.BLACK, true);
        recTitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rp = matchWrap(); rp.setMargins(0, dp(18), 0, 0);
        root.addView(recTitle, rp);

        TextView recHint = text(
                "Нажми запись → вернись домой → сделай несколько медленных/быстрых свайпов, возвратов и недосвайпов → вернись сюда → останови → сохрани TSV и загрузи его в чат. В файле будут touch, реальные bounds и фактическая позиция стекла с таймстампами.",
                13.5f, Color.DKGRAY, false);
        recHint.setGravity(Gravity.CENTER);
        root.addView(recHint, matchWrap());

        recordButton = new Button(this);
        recordButton.setOnClickListener(v -> toggleRecording());
        root.addView(recordButton, matchWrap());

        Button saveTrace = new Button(this);
        saveTrace.setText("СОХРАНИТЬ TRACE.TSV");
        saveTrace.setOnClickListener(v -> saveTrace());
        root.addView(saveTrace, matchWrap());

        recorderStatus = text("", 14f, Color.DKGRAY, true);
        recorderStatus.setGravity(Gravity.CENTER);
        root.addView(recorderStatus, matchWrap());

        debugButton = new Button(this);
        debugButton.setOnClickListener(v -> {
            boolean d = prefs.getBoolean(Prefs.KEY_SHOW_DEBUG, false);
            prefs.edit().putBoolean(Prefs.KEY_SHOW_DEBUG, !d).apply();
            bumpGeneration();
        });
        LinearLayout.LayoutParams dp = matchWrap(); dp.setMargins(0, dp(16), 0, dp(6));
        root.addView(debugButton, dp);

        Button save = new Button(this);
        save.setText("СОХРАНИТЬ СТРАНИЦУ И НАСТРОЙКИ");
        save.setOnClickListener(v -> bumpGeneration());
        root.addView(save, matchWrap());

        Button wallpaper = new Button(this);
        wallpaper.setText("ВЫБРАТЬ / ОБНОВИТЬ ЖИВЫЕ ОБОИ");
        wallpaper.setOnClickListener(v -> { bumpGeneration(); openWallpaperPicker(); });
        root.addView(wallpaper, matchWrap());

        setContentView(scroll);
        refresh();
    }

    private void calibrateAnchor() {
        String label = anchorEdit.getText() == null ? "" : anchorEdit.getText().toString().trim();
        if (label.isEmpty()) label = Prefs.DEFAULT_BOUNDS_ANCHOR_LABEL;
        int page = prefs.getInt(Prefs.KEY_SAVED_PAGE, 0);
        prefs.edit()
                .putString(Prefs.KEY_BOUNDS_ANCHOR_LABEL, label)
                .putInt(Prefs.KEY_BOUNDS_ANCHOR_PAGE, page)
                .remove(Prefs.KEY_BOUNDS_ANCHOR_REST_X)
                .remove(Prefs.KEY_BOUNDS_ANCHOR_REST_Y)
                .putBoolean(Prefs.KEY_BOUNDS_ANCHOR_CALIBRATE_PENDING, true)
                .apply();
        anchorEdit.setText(label);
        Toast.makeText(this, "Теперь вернись на Home, не листай ~1 секунду. Якорь запомнится автоматически.", Toast.LENGTH_LONG).show();
        refresh();
    }

    private void toggleRecording() {
        if (SwipeTrace.isRecording()) SwipeTrace.stop();
        else SwipeTrace.start();
        refresh();
    }

    private void saveTrace() {
        SwipeTrace.stop();
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/tab-separated-values");
        i.putExtra(Intent.EXTRA_TITLE, "oneui_swipe_trace_v0.22.tsv");
        startActivityForResult(i, REQ_SAVE_TRACE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SAVE_TRACE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            boolean ok = uri != null && SwipeTrace.writeToUri(this, uri);
            Toast.makeText(this, ok ? "Trace сохранён" : "Не удалось сохранить trace", Toast.LENGTH_LONG).show();
            refresh();
        }
    }

    private LinearLayout makeStepper(TextView value, boolean pages) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        Button minus = new Button(this); minus.setText("−");
        Button plus = new Button(this); plus.setText("+");
        LinearLayout.LayoutParams side = new LinearLayout.LayoutParams(dp(84), dp(56));
        LinearLayout.LayoutParams center = new LinearLayout.LayoutParams(dp(120), dp(56));
        minus.setOnClickListener(v -> { if (pages) changePageCount(-1); else changeCurrentPage(-1); });
        plus.setOnClickListener(v -> { if (pages) changePageCount(1); else changeCurrentPage(1); });
        row.addView(minus, side); row.addView(value, center); row.addView(plus, side);
        return row;
    }

    private void changePageCount(int delta) {
        int count = clamp(prefs.getInt(Prefs.KEY_PAGE_COUNT, 4) + delta, 2, 9);
        int page = clamp(prefs.getInt(Prefs.KEY_SAVED_PAGE, 0), 0, count - 1);
        prefs.edit().putInt(Prefs.KEY_PAGE_COUNT, count).putInt(Prefs.KEY_SAVED_PAGE, page).apply();
        refresh();
    }

    private void changeCurrentPage(int delta) {
        int count = prefs.getInt(Prefs.KEY_PAGE_COUNT, 4);
        int page = clamp(prefs.getInt(Prefs.KEY_SAVED_PAGE, 0) + delta, 0, count - 1);
        prefs.edit().putInt(Prefs.KEY_SAVED_PAGE, page).apply();
        refresh();
    }

    private void bumpGeneration() {
        int g = prefs.getInt(Prefs.KEY_CONFIG_GENERATION, 0);
        prefs.edit().putInt(Prefs.KEY_CONFIG_GENERATION, g + 1).apply();
        refresh();
    }

    private void refresh() {
        if (pagesValue == null) return;
        int count = prefs.getInt(Prefs.KEY_PAGE_COUNT, 4);
        int page = clamp(prefs.getInt(Prefs.KEY_SAVED_PAGE, 0), 0, count - 1);
        pagesValue.setText(String.valueOf(count));
        currentValue.setText((page + 1) + " / " + count);
        boolean debug = prefs.getBoolean(Prefs.KEY_SHOW_DEBUG, false);
        debugButton.setText(debug ? "ОТЛАДКА: ВКЛ" : "ОТЛАДКА: ВЫКЛ");

        String label = prefs.getString(Prefs.KEY_BOUNDS_ANCHOR_LABEL, Prefs.DEFAULT_BOUNDS_ANCHOR_LABEL);
        boolean pending = prefs.getBoolean(Prefs.KEY_BOUNDS_ANCHOR_CALIBRATE_PENDING, false);
        int ap = prefs.getInt(Prefs.KEY_BOUNDS_ANCHOR_PAGE, -1);
        int rx = prefs.getInt(Prefs.KEY_BOUNDS_ANCHOR_REST_X, -1);
        if (pending) {
            anchorStatus.setText("ЖДУ КАЛИБРОВКУ: " + label + " на странице " + (ap + 1));
            anchorStatus.setTextColor(Color.rgb(145, 75, 20));
        } else if (ap >= 0 && rx >= 0) {
            anchorStatus.setText(String.format(Locale.US, "ЯКОРЬ ГОТОВ: %s · page %d · restX=%d · liveX=%d · pos=%.3f",
                    label, ap + 1, rx, LauncherScrollBus.boundsCenterX, LauncherScrollBus.boundsPosition));
            anchorStatus.setTextColor(Color.rgb(20, 125, 65));
        } else {
            anchorStatus.setText("Якорь пока не откалиброван");
            anchorStatus.setTextColor(Color.rgb(145, 75, 20));
        }

        boolean rec = SwipeTrace.isRecording();
        recordButton.setText(rec ? "ОСТАНОВИТЬ ЗАПИСЬ" : "НАЧАТЬ ЗАПИСЬ СВАЙПОВ");
        recorderStatus.setText((rec ? "REC ●  " : "REC остановлен · ") + SwipeTrace.lineCount() + " строк");
        recorderStatus.setTextColor(rec ? Color.rgb(180, 25, 25) : Color.DKGRAY);
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(sp); v.setTextColor(color);
        if (bold) v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        return v;
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void openWallpaperPicker() {
        ComponentName component = new ComponentName(this, ProbeWallpaperService.class);
        Intent direct = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        direct.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component);
        try { startActivity(direct); }
        catch (Exception ignored) { startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)); }
    }
}
