package com.example.samsungwallpaperprobe;

/** In-process bridge between One UI accessibility sampling and the wallpaper. */
public final class LauncherScrollBus {
    private LauncherScrollBus() {}

    public static volatile boolean serviceConnected = false;

    // Raw accessibility-event diagnostics. These are recorded, but v0.22 no longer uses
    // them to choose/animate pages.
    public static volatile long sequence = 0L;
    public static volatile long eventUptimeMs = 0L;
    public static volatile int eventType = 0;
    public static volatile int scrollX = -1;
    public static volatile int scrollY = -1;
    public static volatile int maxScrollX = -1;
    public static volatile int maxScrollY = -1;
    public static volatile int deltaX = 0;
    public static volatile int deltaY = 0;
    public static volatile int fromIndex = -1;
    public static volatile int toIndex = -1;
    public static volatile int itemCount = -1;
    public static volatile String className = "";
    public static volatile String summary = "";

    // Bounds anchor.
    public static volatile long boundsSequence = 0L;
    public static volatile long boundsChangeSequence = 0L;
    public static volatile boolean boundsFound = false;
    public static volatile boolean boundsCalibrated = false;
    public static volatile long boundsUptimeMs = 0L;
    public static volatile long boundsChangeUptimeMs = 0L;
    public static volatile String boundsAnchor = "";
    public static volatile int boundsAnchorPage = -1; // zero based
    public static volatile int boundsRestX = -1;
    public static volatile int boundsRestY = -1;
    public static volatile int boundsLeft = 0;
    public static volatile int boundsTop = 0;
    public static volatile int boundsRight = 0;
    public static volatile int boundsBottom = 0;
    public static volatile int boundsCenterX = 0;
    public static volatile int boundsCenterY = 0;
    public static volatile float boundsPosition = Float.NaN;
    public static volatile long boundsSamples = 0L;
    public static volatile long boundsChanges = 0L;
    public static volatile String boundsNodeText = "";

    public static volatile int authoritativePage = -1;
    public static volatile long authoritativePageUptimeMs = 0L;
}
