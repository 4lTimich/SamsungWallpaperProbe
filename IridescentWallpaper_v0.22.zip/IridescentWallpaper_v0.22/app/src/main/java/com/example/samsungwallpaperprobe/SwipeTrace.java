package com.example.samsungwallpaperprobe;

import android.content.Context;
import android.net.Uri;
import android.os.SystemClock;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Small in-process recorder used only for user-requested diagnostics.
 * It stores numeric motion telemetry; no accessibility tree text is exported.
 */
public final class SwipeTrace {
    private SwipeTrace() {}

    private static final Object LOCK = new Object();
    private static final int MAX_LINES = 24000;
    private static boolean recording = false;
    private static long startMs = 0L;
    private static int lines = 0;
    private static StringBuilder data = new StringBuilder(512 * 1024);

    public static void start() {
        synchronized (LOCK) {
            recording = true;
            startMs = SystemClock.uptimeMillis();
            lines = 0;
            data = new StringBuilder(512 * 1024);
            data.append("t_ms\tsource\tkind\ttouch_x\ttouch_y\ttouch_dx\ttouch_vx\tbounds_x\tbounds_pos\tglass_pos\tpage\ttarget\tnote\n");
        }
    }

    public static void stop() {
        synchronized (LOCK) { recording = false; }
    }

    public static boolean isRecording() {
        synchronized (LOCK) { return recording; }
    }

    public static int lineCount() {
        synchronized (LOCK) { return lines; }
    }

    public static void log(long eventUptimeMs, String source, String kind,
                           float touchX, float touchY, float touchDx, float touchVx,
                           int boundsX, float boundsPos, float glassPos,
                           int page, int target, String note) {
        synchronized (LOCK) {
            if (!recording || lines >= MAX_LINES) return;
            long t = Math.max(0L, eventUptimeMs - startMs);
            data.append(t).append('\t')
                    .append(clean(source)).append('\t')
                    .append(clean(kind)).append('\t')
                    .append(f(touchX)).append('\t')
                    .append(f(touchY)).append('\t')
                    .append(f(touchDx)).append('\t')
                    .append(f(touchVx)).append('\t')
                    .append(boundsX == Integer.MIN_VALUE ? "" : Integer.toString(boundsX)).append('\t')
                    .append(f(boundsPos)).append('\t')
                    .append(f(glassPos)).append('\t')
                    .append(page < 0 ? "" : Integer.toString(page)).append('\t')
                    .append(target < 0 ? "" : Integer.toString(target)).append('\t')
                    .append(clean(note)).append('\n');
            lines++;
        }
    }

    public static boolean writeToUri(Context context, Uri uri) {
        String snapshot;
        synchronized (LOCK) { snapshot = data.toString(); }
        try (OutputStream out = context.getContentResolver().openOutputStream(uri, "w")) {
            if (out == null) return false;
            out.write(snapshot.getBytes(StandardCharsets.UTF_8));
            out.flush();
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ');
    }

    private static String f(float v) {
        if (Float.isNaN(v) || Float.isInfinite(v)) return "";
        return String.format(Locale.US, "%.4f", v);
    }
}
