# Iridescent Wallpaper v0.22 — Hybrid Anchor + Swipe Recorder

This version deliberately returns to the manual glass grid and raw touch model.
The new part is a single calibrated One UI icon used as an absolute position anchor.

## Motion model

- The grid remains the source of glass placement.
- Raw WallpaperService touch provides low-latency motion between Samsung accessibility updates.
- A single `boundsInScreen` icon anchor periodically re-anchors the motion to One UI's real position.
- Legacy accessibility scroll/page heuristics are disabled in the renderer.
- Rendering loop targets 120 Hz.

## Anchor calibration

1. In the app, set **Current page** to the page that contains the marker icon.
2. Enter the marker label, e.g. `Pinterest`.
3. Tap **CALIBRATE ANCHOR ON CURRENT PAGE**.
4. Return Home and leave that page still for about one second.
5. The service stores the icon's resting X/Y. Afterwards global page position is derived from:
   `anchorPage + (restX - currentX) / screenWidth`.

During a finger drag, timestamped MotionEvent history fills the gap between two bounds samples.

## Swipe recorder

Tap **START SWIPE RECORDING**, go Home, perform test gestures, return to the app, stop and save `oneui_swipe_trace_v0.22.tsv`.
The trace contains timestamps for touch/history samples, real bounds changes and rendered glass position.
Upload that TSV to the chat for analysis.

Recommended recording sequence:
1. very slow 10–20% drag and return without releasing;
2. slow partial drag, release so One UI springs back;
3. normal full swipe to next page;
4. fast left-right reversals while the finger stays down;
5. full swipe back.

The grid editor and existing cell assignments are retained.
